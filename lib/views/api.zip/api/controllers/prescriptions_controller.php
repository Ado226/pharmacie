<?php
// Fichier: server/api/controllers/prescriptions_controller.php
// Contrôleur pour gérer les ordonnances

class PrescriptionsController {
    private $conn;
    
    public function __construct() {
        $this->conn = getDbConnection();
    }
    
    // Méthode pour lister toutes les ordonnances
    public function index() {
        $stmt = $this->conn->prepare("
            SELECT p.id, p.user_id, p.name, p.created_at, p.status, p.selected_pharmacy_id
            FROM prescriptions p
            ORDER BY p.created_at DESC
        ");
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $prescriptions = [];
        
        while ($row = $result->fetch_assoc()) {
            // Récupérer les médicaments associés à l'ordonnance
            $medications = $this->getPrescriptionMedications($row['id']);
            
            $prescription = [
                'id' => $row['id'],
                'user_id' => $row['user_id'],
                'name' => $row['name'],
                'created_at' => $row['created_at'],
                'status' => $row['status'],
                'selected_pharmacy_id' => $row['selected_pharmacy_id'],
                'medications' => $medications
            ];
            
            $prescriptions[] = $prescription;
        }
        
        $stmt->close();
        
        // Envoyer la réponse JSON
        sendJsonResponse($prescriptions);
    }
    
    // Méthode pour afficher une ordonnance spécifique
    public function show($id) {
        $stmt = $this->conn->prepare("
            SELECT p.id, p.user_id, p.name, p.created_at, p.status, p.selected_pharmacy_id
            FROM prescriptions p
            WHERE p.id = ?
        ");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            handleError('Ordonnance non trouvée', 404);
        }
        
        $row = $result->fetch_assoc();
        
        // Récupérer les médicaments associés à l'ordonnance
        $medications = $this->getPrescriptionMedications($row['id']);
        
        $prescription = [
            'id' => $row['id'],
            'user_id' => $row['user_id'],
            'name' => $row['name'],
            'created_at' => $row['created_at'],
            'status' => $row['status'],
            'selected_pharmacy_id' => $row['selected_pharmacy_id'],
            'medications' => $medications
        ];
        
        $stmt->close();
        
        // Envoyer la réponse JSON
        sendJsonResponse($prescription);
    }
    
    // Méthode pour créer une nouvelle ordonnance
    public function store() {
        // Récupérer les données JSON envoyées
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Vérifier les données requises
        if (!isset($data['name']) || !isset($data['medications'])) {
            handleError('Données incomplètes', 400);
        }
        
        // Générer un ID unique pour l'ordonnance
        $id = uniqid('PRESC-');
        $userId = isset($data['user_id']) ? $data['user_id'] : null;
        $name = $data['name'];
        $status = 'en_attente';
        
        // Démarrer une transaction
        $this->conn->begin_transaction();
        
        try {
            // Insérer l'ordonnance
            $stmt = $this->conn->prepare("
                INSERT INTO prescriptions (id, user_id, name, created_at, status)
                VALUES (?, ?, ?, NOW(), ?)
            ");
            $stmt->bind_param("ssss", $id, $userId, $name, $status);
            $stmt->execute();
            
            // Insérer les médicaments associés
            foreach ($data['medications'] as $medication) {
                $medicationId = $medication['medication']['id'];
                $patientType = $medication['patient_type'] === 'enfant' ? 'enfant' : 'adulte';
                
                $stmt = $this->conn->prepare("
                    INSERT INTO prescription_medications (prescription_id, medication_id, patient_type)
                    VALUES (?, ?, ?)
                ");
                $stmt->bind_param("sss", $id, $medicationId, $patientType);
                $stmt->execute();
            }
            
            // Valider la transaction
            $this->conn->commit();
            
            // Envoyer la réponse JSON
            sendJsonResponse([
                'id' => $id,
                'message' => 'Ordonnance créée avec succès'
            ]);
        } catch (Exception $e) {
            // Annuler la transaction en cas d'erreur
            $this->conn->rollback();
            handleError('Erreur lors de la création de l\'ordonnance: ' . $e->getMessage());
        }
    }
    
    // Méthode pour mettre à jour une ordonnance existante
    public function update($id) {
        // Récupérer les données JSON envoyées
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Vérifier les données requises
        if (!isset($data['name'])) {
            handleError('Données incomplètes', 400);
        }
        
        $name = $data['name'];
        $status = isset($data['status']) ? $data['status'] : null;
        $selectedPharmacyId = isset($data['selected_pharmacy_id']) ? $data['selected_pharmacy_id'] : null;
        
        // Démarrer une transaction
        $this->conn->begin_transaction();
        
        try {
            // Mettre à jour l'ordonnance
            if ($status && $selectedPharmacyId) {
                $stmt = $this->conn->prepare("
                    UPDATE prescriptions
                    SET name = ?, status = ?, selected_pharmacy_id = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("ssss", $name, $status, $selectedPharmacyId, $id);
            } elseif ($status) {
                $stmt = $this->conn->prepare("
                    UPDATE prescriptions
                    SET name = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("sss", $name, $status, $id);
            } else {
                $stmt = $this->conn->prepare("
                    UPDATE prescriptions
                    SET name = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("ss", $name, $id);
            }
            $stmt->execute();
            
            // Si des médicaments sont fournis, mettre à jour les associations
            if (isset($data['medications'])) {
                // Supprimer les anciennes associations
                $stmt = $this->conn->prepare("
                    DELETE FROM prescription_medications
                    WHERE prescription_id = ?
                ");
                $stmt->bind_param("s", $id);
                $stmt->execute();
                
                // Insérer les nouvelles associations
                foreach ($data['medications'] as $medication) {
                    $medicationId = $medication['medication']['id'];
                    $patientType = $medication['patient_type'] === 'enfant' ? 'enfant' : 'adulte';
                    
                    $stmt = $this->conn->prepare("
                        INSERT INTO prescription_medications (prescription_id, medication_id, patient_type)
                        VALUES (?, ?, ?)
                    ");
                    $stmt->bind_param("sss", $id, $medicationId, $patientType);
                    $stmt->execute();
                }
            }
            
            // Valider la transaction
            $this->conn->commit();
            
            // Envoyer la réponse JSON
            sendJsonResponse([
                'message' => 'Ordonnance mise à jour avec succès'
            ]);
        } catch (Exception $e) {
            // Annuler la transaction en cas d'erreur
            $this->conn->rollback();
            handleError('Erreur lors de la mise à jour de l\'ordonnance: ' . $e->getMessage());
        }
    }
    
    // Méthode pour supprimer une ordonnance
    public function destroy($id) {
        try {
            // Supprimer l'ordonnance (les associations seront supprimées automatiquement grâce à ON DELETE CASCADE)
            $stmt = $this->conn->prepare("
                DELETE FROM prescriptions
                WHERE id = ?
            ");
            $stmt->bind_param("s", $id);
            $stmt->execute();
            
            if ($stmt->affected_rows === 0) {
                handleError('Ordonnance non trouvée', 404);
            }
            
            // Envoyer la réponse JSON
            sendJsonResponse([
                'message' => 'Ordonnance supprimée avec succès'
            ]);
        } catch (Exception $e) {
            handleError('Erreur lors de la suppression de l\'ordonnance: ' . $e->getMessage());
        }
    }
    
    // Méthode pour récupérer les médicaments associés à une ordonnance
    private function getPrescriptionMedications($prescriptionId) {
        $stmt = $this->conn->prepare("
            SELECT pm.medication_id, pm.patient_type,
                   m.name, m.description, m.form, m.dosage, m.usage, m.image_url, m.price
            FROM prescription_medications pm
            JOIN medications m ON pm.medication_id = m.id
            WHERE pm.prescription_id = ?
        ");
        $stmt->bind_param("s", $prescriptionId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $medications = [];
        
        while ($row = $result->fetch_assoc()) {
            $medication = [
                'medication' => [
                    'id' => $row['medication_id'],
                    'name' => $row['name'],
                    'description' => $row['description'],
                    'form' => $row['form'],
                    'dosage' => $row['dosage'],
                    'usage' => $row['usage'],
                    'image_url' => $row['image_url'],
                    'price' => $row['price'] ? (float) $row['price'] : null,
                ],
                'patient_type' => $row['patient_type']
            ];
            
            $medications[] = $medication;
        }
        
        $stmt->close();
        return $medications;
    }
}